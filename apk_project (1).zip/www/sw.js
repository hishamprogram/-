(function swBody(){const C='hr-pwa-v4';
 self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.add(new Request(self.registration.scope,{cache:'reload'}))).catch(()=>{}).then(()=>self.skipWaiting()))});
 self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
 self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);if(u.searchParams.has('_chk'))return;const own=u.origin===self.location.origin,cdn=u.hostname==='cdnjs.cloudflare.com';if(!own&&!cdn)return;
  const upd=()=>fetch(r).then(res=>{if(res&&(res.ok||res.type==='opaque')){const a=res.clone(),b=res.clone();caches.open(C).then(c=>{c.put(r,a);if(r.mode==='navigate')c.put(self.registration.scope,b)})}return res});
  if(r.mode==='navigate'){e.respondWith(caches.match(r,{ignoreSearch:true}).then(h=>h||caches.match(self.registration.scope)).then(h=>{const n=upd().catch(()=>null);return h||n.then(x=>x||new Response('غير متصل',{status:503,headers:{'Content-Type':'text/plain;charset=utf-8'}}))}));return}
  e.respondWith(caches.match(r).then(h=>{const n=upd().catch(()=>h);return h||n}))})})();
