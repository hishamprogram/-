package com.remas.attendance;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import com.getcapacitor.BridgeActivity;

import java.io.OutputStream;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            getBridge().getWebView().addJavascriptInterface(new NativeBridge(), "AndroidApp");
        } catch (Throwable t) {
            // الجسر غير متاح: يعمل التطبيق دون الطباعة والحفظ الأصليين
        }
    }

    public class NativeBridge {
        @JavascriptInterface
        public void print(final String title, final boolean landscape) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        WebView w = getBridge().getWebView();
                        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                        PrintAttributes.MediaSize size = landscape
                                ? PrintAttributes.MediaSize.ISO_A4.asLandscape()
                                : PrintAttributes.MediaSize.ISO_A4;
                        PrintAttributes attrs = new PrintAttributes.Builder()
                                .setMediaSize(size)
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        pm.print(title, w.createPrintDocumentAdapter(title), attrs);
                    } catch (Throwable t) {
                        Toast.makeText(MainActivity.this, "تعذرت الطباعة", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public String save(String name, String mime, String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return "err";
                OutputStream os = getContentResolver().openOutputStream(uri);
                os.write(data);
                os.close();
                return "ok";
            } catch (Throwable t) {
                return "err";
            }
        }
    }
}
